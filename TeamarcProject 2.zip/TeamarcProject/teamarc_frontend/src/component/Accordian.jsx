import React, { useState, useRef } from "react";

import Rotateicon from "./Rotateicon";
import Lesson from "./Lesson";

import "./Accordian.css";

function Accordian(props) {
  const [setActive, setActiveState] = useState("");
  const [setHeight, setHeightState] = useState("0px");
  const [setRotate, setRotateState] = useState("accordion__icon");

  const content = useRef(null);
  const [chapterData, setChapterData] = useState({});
  const [responseError, setResponseErrors] = useState({});
  const [chapterResponse, setChapterResponse] = useState({});

  async function fetchData() {
    await fetch(
      "http://127.0.0.1:3001/api/book/maths/section/" + props.bookInfo.id + ""
    )
      .then((response) => {
        setChapterResponse(response);
        return response.json();
      })
      .then((body) => setChapterData(body.response))
      .catch((err) => setResponseErrors(err));
  }

  async function toggleAccordion() {
    await fetchData();

    setActiveState(setActive === "" ? "active" : "");
    setHeightState(
      setActive === "active" ? "0px" : `${content.current.scrollHeight}px`
    );
    setRotateState(
      setActive === "active" ? "accordion__icon" : "accordion__icon rotate"
    );
  }
  const id = props.bookInfo.id;
  const chapData = chapterData === {} ? [] : chapterData[id];

  return (
    <div className="accordion__section">
      <button
        className={`accordion ${setActive}`}
        onClick={toggleAccordion}
        id={props.bookInfo.id}
      >
        <div className="accordion__title" style={{ width: "85%" }}>
          {props.bookInfo.sequenceNO}. {props.title}
        </div>
        <div className="progress">
          {props.bookInfo.childrenCount === 0 ? 0 : props.bookInfo.completeCount}
          /{props.bookInfo.childrenCount}
        </div>
        <Rotateicon className={`${setRotate}`} width={10} fill={"#777"} />
      </button>
      <div
        ref={content}
        style={{ maxHeight: `${setHeight}` }}
        className="accordion__content"
      >
        <div>
          <ul>
            {chapData !== undefined
              ? chapData
                  .sort((a, b) => (a.sequenceNO < b.sequenceNO ? -1 : 1))
                  .map((ele) => (
                    <li
                      onClick={() => props.setData(ele)}
                      className='accordion-sublist'
                      style={{
                        padding: "10px",
                        color:
                          ele.status !== "NOT_STARTED"
                            ? ele.status === "COMPLETE"
                              ? "green"
                              : "orange"
                            : "gray",
                      }}
                    >
                      {" "}
                      <Lesson width={10} fill={"#777"} />
                      &nbsp;&nbsp;<span>{ele.title}</span>
                    </li>
                  ))
              : ""}
          </ul>
        </div>
      </div>
    </div>
  );
}

export default Accordian;
