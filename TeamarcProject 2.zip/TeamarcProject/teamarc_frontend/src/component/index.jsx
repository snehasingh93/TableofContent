import React from "react";

import Accordian from "./Accordian.jsx";

import "./style.css";
import { useEffect, useState } from "react";

function Index() {
  const [bookData, setBookData] = useState({});
  const [responseError, setResponseErrors] = useState({});
  const [bookResponse, setBookResponse] = useState({});
  const [mainContent, setMainContent] = useState({});

  async function fetchData() {
    await fetch("http://127.0.0.1:3001/api/book/maths")
      .then((response) => {
        setBookResponse(response);
        return response.json();
      })
      .then((body) => setBookData(body))
      .catch((err) => setResponseErrors(err));
  }
  
  useEffect(() => {
    fetchData();
  }, []);

  const { response = [] } = bookData;
  const setMainContentState = (param) => setMainContent(param);

  return (
    <>
      <div className="header">
        <span style={{ marginLeft: "71px", fontSize: "27px" }}>
          Mathematics Content
        </span>
        <span style={{ float: "right", fontSize: "25px" }}>Teamarc</span>
      </div>
      <div className="row">
        <div className="side">
          <h2 className="App">Table of Content</h2>
          <br></br>
          <div style={{boxShadow:' 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19)'}}>
            {response
              .sort((a, b) => (a.sequenceNO < b.sequenceNO ? -1 : 1))
              .map((book) => (
                <Accordian
                  title={book.title}
                  key={book.sequenceNO}
                  bookInfo={book}
                  setData={setMainContentState}
                />
              ))}
          </div>
        </div>
        <div className="main">
          <div className="mainsection">
            {mainContent.title ? (
              <>
                <h2
                  style={{
                    textAlign: "center",
                    padding: "27px 0",
                    textTransform: "capitalize",
                  }}
                >
                  {mainContent.type}: {mainContent.title}
                </h2>
                <p style={{ padding: "0px 26px" }}>Content will be soon...</p>
              </>
            ) : (
              ""
            )}
          </div>
        </div>
      </div>
    </>
  );
}

export default Index;
