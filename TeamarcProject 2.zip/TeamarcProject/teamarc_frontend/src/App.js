import React from "react";
import Accordian from "./component/index";

function App() {
  return (
    <div>
      <Accordian />
    </div>
  );
}

export default App;
